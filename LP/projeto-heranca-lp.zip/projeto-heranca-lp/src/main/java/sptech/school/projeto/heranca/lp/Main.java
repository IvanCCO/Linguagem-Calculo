/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sptech.school.projeto.heranca.lp;

/**
 *
 * @author aluno
 */
public class Main {
  
    public static void main(String[] args) {
        
        AlunoPos alunoPos = new AlunoPos(7.0, 47294298, "Ivan", 9.0, 9.2);
        
    }
    
}
