package com.mycompany.lista_3.teste.media;


public class CalcMedia {
    
    double calcularMedia(double nota1,double nota2){
        
       double z = ((nota1 * 0.4) + (nota2 * 0.6));
       
       return z;
    }
    
}
