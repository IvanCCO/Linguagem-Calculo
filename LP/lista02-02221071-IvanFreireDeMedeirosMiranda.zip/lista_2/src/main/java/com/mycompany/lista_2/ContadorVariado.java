package com.mycompany.lista_2;

public class ContadorVariado {
      
    public static void main(String[] args) {
        
        double valor = 0.15;
        while(valor<5){
            System.out.printf("%.2f %n", valor);
            valor += 0.15;
        }
            
    }
}
